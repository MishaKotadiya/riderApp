package com.example.riderapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
